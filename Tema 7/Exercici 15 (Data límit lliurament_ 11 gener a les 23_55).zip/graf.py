# -*- coding: utf-8 -*-


import copy as cp
import numpy as np
class Graf:
    __slots__ = {'__nodes', '__arestes'}
        
    def __init__(self, nodes, arestes, pesos):
        self.__nodes = cp.deepcopy(nodes)
        self.__arestes = np.zeros([len(nodes), len(nodes)])
        for aresta, pes in zip(arestes, pesos):
            self.__arestes[aresta[0],aresta[1]] = pes
            self.__arestes[aresta[1],aresta[0]] = pes
            
    def __str__(self):
        s = "";
        for posNode, node in enumerate(self.__nodes):
            s = s + "Etiqueta: " + str(node) + "\n"
            s = s + "Arestes: " + str([[vei[0], pes] for vei, pes in np.ndenumerate(self.__arestes[posNode,:]) if pes != 0]) + "\n"
        return s
    
    def cicles(self):
          
    def nodeMaxArestes(self):
    
    def nodesAillats(self):
       
    def etiquetesAdjacents(self, node):
    
    
        
                
 