# -*- coding: utf-8 -*-
"""
Created on Wed Jan 24 10:43:25 2018

@author: ernest
"""
import random

def afegeixSinonim(diccionari, paraula, sinonim):



def conversioSinonims(frase, diccionari):

    
