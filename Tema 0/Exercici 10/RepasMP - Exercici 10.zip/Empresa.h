#pragma once
#include "Comanda.h"
#include "Producte.h"

class Empresa
{

};