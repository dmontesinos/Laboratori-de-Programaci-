# -*- coding: utf-8 -*-

class Graf:
    __slots__ = {'__nodes'}
        
    def __init__(self, nodes, arestes, pesos):
        self.__nodes = [[node, []] for node in nodes]
        for aresta, pes in zip(arestes, pesos):
            self.__nodes[aresta[0]][1].append([aresta[1], pes])
            self.__nodes[aresta[1]][1].append([aresta[0], pes])
            
    def __str__(self):
        s = "";
        for node in self.__nodes:
            s = s + "Comment :=>> Etiqueta: " + str(node[0]) + "\n"
            s = s + "Comment :=>> Arestes: " + str(node[1]) + "\n"
        return s
    
    def cicles(self):
    
    
    def nodeMaxArestes(self):
    
    def nodesAillats(self):
    
    def etiquetesAdjacents(self, node):
    
    
        
                
 
       
            