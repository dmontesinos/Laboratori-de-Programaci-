#pragma once

class Producte
{
};
